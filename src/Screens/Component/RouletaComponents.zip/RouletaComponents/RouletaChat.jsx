import React from "react";
import "./React_Rouleta.css";

function RouletaChat() {
  return (
    <div className="Rouleta_Chat_main_div">
      <div className="Rouleta_Chat_Para_div">
        <h4>Juan Carlos</h4>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Non delectus
          officia numquam reiciendis deleniti mollitia adipisci?{" "}
        </p>
      </div>
      <div className="Rouleta_Chat_Para_div">
        <h4>Juan Carlos</h4>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Non delectus
          officia numquam reiciendis deleniti mollitia adipisci?{" "}
        </p>
      </div>
      <div className="Rouleta_Chat_Para_div">
        <h4>Juan Carlos</h4>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Non delectus
          officia numquam reiciendis deleniti mollitia adipisci?{" "}
        </p>
      </div>
      <div className="Rouleta_Chat_Para_div">
        <h4>Juan Carlos</h4>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Non delectus
          officia numquam reiciendis deleniti mollitia adipisci?{" "}
        </p>
      </div>
      <div className="Rouleta_Chat_Para_div">
        <h4>Juan Carlos</h4>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Non delectus
          officia numquam reiciendis deleniti mollitia adipisci?{" "}
        </p>
      </div>
      <div className="Rouleta_Chat_Para_div">
        <h4>Juan Carlos</h4>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Non delectus
          officia numquam reiciendis deleniti mollitia adipisci?{" "}
        </p>
      </div>
      <textarea
        className="textarea_chat"
        placeholder="Type Your messages here"
      ></textarea>
      <button className="textarea_chat_button">Send</button>
    </div>
  );
}

export default RouletaChat;
