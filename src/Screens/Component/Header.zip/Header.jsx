import React, { useState } from 'react';
import { Avatar, Button, Modal } from 'antd';
import '../../Styles/Authentication.css';
import SignUp from '../Authentication/SignUp';
import Login from '../Authentication/Login';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from 'react-router-dom';
import ButtonGroup from 'react-bootstrap/ButtonGroup';
import '../../Styles/Header.css'
import { useNavigate } from 'react-router-dom';
import Userprofile from '../Pages/Userprofile';
import DepositeAndWithdrawal from './DepositeAndWithdrawal';

function Header() {
  const [visible, setVisible] = useState(false);
  const [activeTab, setActiveTab] = useState('login');
  const [isLoggedIn, setIsLoggedIn] = useState(false); // State to manage login status
  const [showOptions, setShowOptions] = useState(false);
  const navigate = useNavigate();
  const [balance, setBalance] = useState(1000); // Initial balance set to 1000
  const [depositeModalVisible, seDepositeModalVisible] = useState(false);

  const updateBalance = () => {
    const newBalance = Math.floor(Math.random() * 2000);
    setBalance(newBalance);
  };

  const showModal = () => {
    setVisible(true);
  };

  const handleCancel = () => {
    setVisible(false);
  };

  const handleLoginClick = () => {
    setActiveTab('login');
    showModal();
  };

  const handleSignupClick = () => {
    setActiveTab('signup');
    showModal();
  };

  const handleToggleOptions = () => {
    setShowOptions(!showOptions);
  };

  // Callback function to handle successful login
  const handleLoginSuccess = () => {
    setIsLoggedIn(true);
    setVisible(false); // Close the modal after successful login
    navigate('/casino');
  };

  // Function to handle logout
  const handleLogout = () => {
    setIsLoggedIn(false);
    navigate('/')
  };
  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  // Function to handle login
  const handleLogin = () => {
    // Perform login logic, for example, setting isLoggedIn to true
    setIsLoggedIn(true);
    // Close the modal
    setVisible(false);
  };

  const handleDepositeButtonClick = () => {
    seDepositeModalVisible(true); 
  };

  const handleDepositeModalCancel = () => {
    seDepositeModalVisible(false); 
  };


  return (
    <>
      {/* Render different navbar based on login status */}
      {isLoggedIn ? (
        // Navbar to show after login
        <div>
          <Navbar bg="head" expand="sm" className="bg-head">
            <Container fluid>
              <Navbar.Brand>
                <div style={{ maxWidth: '180px' }} className='d-flex align-items-center'>
                  <img src={require('../../Assets/Icon/csinos logo 2.png')} alt="" />
                  <h2 style={{ fontSize: '20px', color: '#fff', marginLeft: '10px', marginTop: '10px' }}>Rolling Star</h2>
                </div>
              </Navbar.Brand>
              <Navbar.Toggle style={{ filter: 'invert(12)' }} onClick={handleToggleOptions} aria-controls="basic-navbar-nav" />
              <Navbar.Collapse id="basic-navbar-nav" className='justify-content-end'>
                <Nav className={`align-items-center ml-auto ${showOptions ? '' : 'd-none'} d-sm-flex`}>
                  <ButtonGroup horizontal className='w-100 align-items-center nav-2-mobile gap-3 mt-2'>
                    <Link style={{ fontSize: '18px', marginRight: '15px' }} className='text-decoration-none text-white' to="/BFGStaking">
                      BFG Staking
                    </Link>
                    <Link style={{ fontSize: '18px', marginRight: '15px' }} className='text-decoration-none text-white' to="/ReferralProgram">
                      Referral program
                    </Link>
                    <div className='wallet-container nav-2-mobile gap-3'>
                      <button className=""  onClick={handleDepositeButtonClick}>
                        <span style={{ fontSize: '16px' }}>Deposit and withdrawal</span>
                      </button>
                      <Modal
                        visible={depositeModalVisible}
                        onCancel={handleDepositeModalCancel}
                        footer={null}
                        className="deposite-modal"
                      >
                        <div>
                          <DepositeAndWithdrawal />
                        </div>
                      </Modal>
                      <div className='wallet'>
                        <div>
                          <Avatar style={{ backgroundColor: '#87d068' }} icon={<img src={require('../../Assets/Icon/cryptocurrency-color_usdt.png')} alt="" />} />
                        </div>
                        <div>
                          <p>${balance}</p>
                        </div>
                      </div>
                      <button className="red-btn"><img src={require('../../Assets/Icon/wallet-bold.png')} alt="" />
                        <span style={{ fontSize: '16px' }}>Wallet</span>
                      </button>
                      <div>
                        <Userprofile handleLogout={handleLogout} />
                      </div>
                    </div>
                  </ButtonGroup>
                </Nav>
              </Navbar.Collapse>
            </Container>
          </Navbar>
        </div>
      ) : (
        // Navbar to show before login
        <div>
          <Navbar bg="head" expand="sm" className="bg-head">
            <Container fluid>
              <Navbar.Brand>
                <div style={{ maxWidth: '180px' }} className='d-flex align-items-center'>
                  <img src={require('../../Assets/Icon/csinos logo 2.png')} alt="" />
                  <h2 style={{ fontSize: '20px', color: '#fff', marginLeft: '10px', marginTop: '10px' }}>Rolling Star</h2>
                </div>
              </Navbar.Brand>
              <Navbar.Toggle style={{ filter: 'invert(12)' }} onClick={handleToggleOptions} aria-controls="basic-navbar-nav" />
              <Navbar.Collapse id="basic-navbar-nav" className='justify-content-end'>
                <Nav className={`align-items-center ml-auto ${showOptions ? '' : 'd-none'} d-sm-flex gap-3`}>
                  <Link className='text-decoration-none' to="/">
                    <a className='text-white text-decoration-none fs-5' rel="stylesheet" href="" >Home</a>
                  </Link>
                  <Link className='text-decoration-none' to="/casino">
                    <a className='text-white text-decoration-none fs-5' rel="stylesheet" href="" >Casino</a>
                  </Link>
                  <button className=""  onClick={handleDepositeButtonClick}>
                        <span style={{ fontSize: '16px' }}>Deposit and withdrawal</span>
                      </button>
                      <Modal
                        visible={depositeModalVisible}
                        onCancel={handleDepositeModalCancel}
                        footer={null}
                        className="deposite-modal"
                      >
                        <div>
                          <DepositeAndWithdrawal />
                        </div>
                      </Modal>
                  <Button className="green-btn fs-5 text-white" onClick={handleLoginClick}><img src={require('../../Assets/Icon/wallet-bold.png')} alt="" /> Log in</Button>
                  <Button className="golden-btn fs-5 text-white" onClick={handleSignupClick}><img src={require('../../Assets/Icon/wallet-bold.png')} alt="" /> Register</Button>
                </Nav>
              </Navbar.Collapse>
            </Container>
          </Navbar>
          <Modal
            visible={visible}
            onCancel={handleCancel}
            footer={null}
            className="custom-modal"
            style={{ maxWidth: '902px', width: '902px', height: '569px' }}
          >
            <div className='signu'>
              <div className="tabs modal-tab">
                <div className='btn-group-model'>
                  <button
                    className={`black-btn ${activeTab === 'login' ? 'active' : ''}`}
                    type="button"
                    onClick={() => handleTabChange('login')}
                    style={{ fontSize: '32px', opacity: '100%', color: 'white' }}
                  >
                    Login
                  </button>
                  <button
                    className={`black-btn ${activeTab === 'signup' ? 'active' : ''}`}
                    type="button"
                    onClick={() => handleTabChange('signup')}
                    style={{ fontSize: '32px', opacity: '100%', color: 'white' }}
                  >
                    Register
                  </button>
                </div>
              </div>
            </div>
            {activeTab === 'login' && (
              <div className="login-form">
                <Login onLogin={handleLoginSuccess} />
              </div>
            )}
            {activeTab === 'signup' && (
              <div className="signup-form">
                <SignUp />
              </div>
            )}
          </Modal>
        </div>
      )}
    </>
  );
}

export default Header;
